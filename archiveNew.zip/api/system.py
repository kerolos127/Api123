from fastapi import APIRouter
from database.api_keys import generate_api_key
import psutil
import platform

router = APIRouter()

@router.post("/create_key")
def create_key(owner: str):
    key = generate_api_key(owner)
    return {"api_key": key}


@router.get("/info")
def system_info():
    return {
        "system": platform.system(),
        "cpu": psutil.cpu_percent(),
        "ram": psutil.virtual_memory().percent
    }
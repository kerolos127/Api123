from fastapi import APIRouter, Depends
from core.executor import execute_command
from core.auth import verify_api_key
from core.logger import log

router = APIRouter()

@router.post("/exec")
def exec_command(
    cmd: str,
    api_key: str = Depends(verify_api_key)
):

    log(f"command executed: {cmd}")

    return execute_command(cmd)